<?php
session_start();
$uname=$_SESSION['uname'];
$pwd=$_SESSION['pwd'];
$fname=$_POST['fname'];
if(isset($_POST['fname']) && isset($_POST['submit']))
{
	$con=mysqli_connect("localhost","root","admin","regis") or die("COULDNT CONNECT TO DATABASE");
	$query=mysqli_query($con,"insert into regis values('$fname','$uname','$pwd')");
	echo "SUCESSFULLY REGISTERED";
}
else
{
	echo "ENTER ALL THE FIELDS";
}
session_destroy();
?>
